/*
Amber Janosh
CS249
Ch 9 Program 2

(TheStockclass) Following the example of the Circle class in Section 9.2,
design a class named Stock that contains:
A string data field named symbol for the stock’s symbol.
A string data field named name for the stock’s name.
A double data field named previousClosingPrice that stores the stock price for
    the previous day.
A double data field named currentPrice that stores the stock price for the
    current time.
A constructor that creates a stock with the specified symbol and name.
A method named getChangePercent() that returns the percentage changed from
    previousClosingPrice to currentPrice.
Write a test pro-gram that creates a Stock object with the stock symbol ORCL,
the name  Oracle Corporation, and the previous closing price of 34.5.
Set a new current price to 34.35 and display the price-change percentage.
 */
import java.text.DecimalFormat;
public class Ch9Prog2 {
    private static DecimalFormat df2 = new DecimalFormat("#.##");
    static class Stock{
        String symbol;
        String name;
        double previousClosingPrice = 0;
        double currentPrice = 0;

        Stock(){}

        Stock(String nSymbol, String nName){
            symbol = nSymbol;
            name = nName;
        }

        double getChangePercent(double nClosing, double nCurrent){
            //price change percentage
            double result = 0;
            double percResult = 0;
            if (nCurrent > nClosing){
                result = ((nCurrent - nClosing)/nClosing)* 100;
                percResult = result * 100;
            }
            else if (nCurrent < nClosing){
                result =((nClosing - nCurrent)/nClosing)*100;
                percResult = result * 100;
            }
            return percResult;
        }
    }

    public static void main(String[] args){
        Stock stockOne = new Stock("ORCL","Oracle");
        System.out.println("The Price Change Percent is " + df2.format(stockOne.getChangePercent(34.5,34.35)) + "%");

    }
}
