import java.util.Calendar;
import java.util.Date;
import java.util.Scanner;
/*
Amber Janosh
CS249
Ch 10 Program 7
*/
/*
Game: ATM machine) Use the Account class created in Programming Exercise 9.7 to simulate
an ATM machine. Create 10 accounts in an array with id 0, 1, . . . , 9, and an
initial balance of $100. The system prompts the user to enter an id. If the id is entered
incorrectly, ask the user to enter a correct id. Once an id is accepted, the main menu
is displayed as shown in the sample run. You can enter choice 1 for viewing the
current balance, 2 for withdraw-ing money, 3 for depositing money, and 4 for exiting
the main menu. Once you exit, the system will prompt for an id again.
Thus, once the system starts, it will not stop.
*/
/*
TheAccountclass) Design a class named Account that contains:
A private int data field named id for the account (default 0).
A private double data field named balance for the account (default 0).
A private double data field named annualInterestRate that stores the current interest rate
(default 0). Assume that all accounts have the same interest rate.
A private Date data field named dateCreated that stores the date when the account was
created.
A no-arg constructor that creates a default account.
A constructor that creates an account with the specified id and initial balance.
The accessor and mutator methods for id, balance, and annualInterestRate.
The accessor method for dateCreated.
A method named getMonthlyInterestRate() that returns the monthly interest rate.
A method named getMonthlyInterest() that returns the monthly interest.
A  method  named  withdraw  that  withdraws  a  specified  amount  from  the  account.
A method named deposit that deposits a specified amount to the account.
(Hint: The method getMonthlyInterest()  is  to  return  monthly  interest,  not  the
interest  rate.  Monthly interest is balance * monthlyInterestRate.
monthlyIntere-stRate is annualInterestRate / 12.
Note annualInterestRate is a per-centage, for example 4.5%. You need to divide it by 100.)
Write a test program that creates an Account object with an account ID of 1122,
a balance of $20,000, and an annual interest rate of 4.5%. Use the withdrawmethod
to withdraw $2,500, use the deposit method to deposit $3,000, and print the balance,
the monthly interest, and the date when this account was created
 */
public class Ch10Prog7 {
    public static class Account{
        private int id;
        private double balance;
        private double annInterestRate = 0;

        Account(){}

        public Account(int accID, double accBalance){
            this.id = accID;
            this.balance = accBalance;
        }

        /*
        Accessor; Get the value of a private field "Getter"
        Mutator; Set the value of a private field "Setter"
         */

        public int getId() {
            return id;
        }

        public double getBalance() {
            return balance;
        }

        public double getAnnInterestRate() {
            return annInterestRate;
        }

        public Date getDateCreated(){
            return new Date(1993, 10,21);
        }

        public void setId(int id) {
            this.id = id;
        }

        public void setBalance(double balance) {
            this.balance = balance;
        }

        public void setAnnInterestRate(double annInterestRate) {
            this.annInterestRate = annInterestRate/100;
        }

        public double getMonthlyInterestRate(){
            return annInterestRate / 12;
        }

        public double getMonthlyInterest(){
            return balance * getMonthlyInterestRate();
        }

        public void withdraw(double monWithdrawn){
            balance = balance - monWithdrawn;
        }

        public void deposit(double monDeposit){
            balance = balance + monDeposit;
        }
    }

        public static void main(String[] args) {
            Scanner input = new Scanner(System.in);
            Account newAccount = new Account(1122,20000);
            newAccount.setAnnInterestRate(4.5);
            newAccount.withdraw(2500);
            newAccount.deposit(3000);
            System.out.println("newAccount balance is " + newAccount.balance);
            System.out.println("newAccount monthly interest rate is " + newAccount.getMonthlyInterest());
            System.out.println("newAccount date created is " + newAccount.getDateCreated());

            Account[] accounts = new Account[10];

            for(int i = 0; i < 10; i++){
                accounts[i] = new Account(i, 100);
            }

            int userID;
            int flag;
            int choice;
            String contin;

            System.out.println("Please enter an ID: ");
            userID = input.nextInt();

            if ((userID < 0) | (userID > 9)) {
                System.out.println("Incorrect Account ID");
                flag = 0;
            }
            else{
                flag = 1;

                while (flag == 1) {
                    System.out.println("Main Menu");
                    System.out.println("1: Check Balance");
                    System.out.println("2: Withdraw");
                    System.out.println("3: Deposit");
                    System.out.println("4: Exit\n");

                    choice = input.nextInt();

                    switch (choice){
                        case 1:{
                            System.out.println("The Account balance is " + accounts[userID].getBalance());
                            System.out.println("Would you like to make another choice? Enter 'yes' or 'no.'\n");
                            contin = (input.next()).toLowerCase();
                            if(contin.equals("no")){
                                flag = 0;
                            }
                            else
                                flag = 1;
                            break;
                        }
                        case 2:{
                            System.out.println("How much would you like to withdraw?\n");
                            double wDraw = input.nextDouble();
                            accounts[userID].withdraw(wDraw);
                            System.out.println("Would you like to make another choice? Enter 'yes' or 'no.'\n");
                            contin = (input.next()).toLowerCase();
                            if(contin.equals("no")){
                                flag = 0;
                            }
                            else
                                flag = 1;
                            break;
                        }
                        case 3:{
                            System.out.println("How much would you like to deposit?\n");
                            double wDeposit = input.nextDouble();
                            accounts[userID].deposit(wDeposit);
                            System.out.println("Would you like to make another choice? Enter 'yes' or 'no.'\n");
                            contin = (input.next()).toLowerCase();
                            if(contin.equals("no")){
                                flag = 0;
                            }
                            else
                                flag = 1;
                            break;
                        }
                        case 4:{
                            System.out.println("Thank you");
                            flag = 0;
                            break;
                        }
                    }
                }
            }
            System.out.println("Goodbye!");
        }
}
