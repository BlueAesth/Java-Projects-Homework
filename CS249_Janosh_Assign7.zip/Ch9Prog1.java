/*
Amber Janosh
CS249
Ch 9 Program 1

(TheRectangleclass) Following the example of the Circle class in Section 9.2,
design a class named Rectangle to represent a rectangle.
The class contains: Two double data fields named width and height that specify
the width and height of the rectangle. The default values are 1 for both width and height.
A no-arg constructor that creates a default rectangle.
A constructor that creates a rectangle with the specified width and height.
A method named getArea() that returns the area of this rectangle.
A method named getPerimeter() that returns the perimeter.Draw the UML diagram for the class
then implement the class. Write a test pro-gram that creates two Rectangle objects
—one with width 4 and height 40, and the other with width 3.5 and height 35.9.
Display the width, height, area, and perimeter of each rectangle in this order.
 */

public class Ch9Prog1 {
    static class Rectangle{
        double width = 1;
        double height = 1;

        Rectangle(){}

        Rectangle(double nWidth, double nHeight){
            width = nWidth;
            height = nHeight;
        }

        double getArea () {
            return width * height;
        }

        double getParameter () {
            return 2 * width + 2 * height;
        }
    }

    public static void main(String[] args){
        Rectangle rectOne = new Rectangle();
        System.out.println("rectOne Height is: " + rectOne.height);
        System.out.println("rectOne Width is: " + rectOne.width);
        System.out.println("rectOne Area is: " + rectOne.getArea());
        System.out.println("rectOne Parameter is " + rectOne.getParameter() + "\n");

        Rectangle rectTwo = new Rectangle(4,40);
        System.out.println("rectTwo Height is: " + rectTwo.height);
        System.out.println("rectTwo Width is: " + rectTwo.width);
        System.out.println("rectTwo Area is: " + rectTwo.getArea());
        System.out.println("rectTwo Parameter is " + rectTwo.getParameter() + "\n");

        Rectangle rectThree = new Rectangle(3.5,35.9);
        System.out.println("rectThree Height is: " + rectThree.height);
        System.out.println("rectThree Width is: " + rectThree.width);
        System.out.println("rectThree Area is: " + rectThree.getArea());
        System.out.println("rectThree Parameter is " + rectThree.getParameter() + "\n");
    }
}
