/* CS 249 Assignment Two
Chapter Two, 2.1-2.6

Program 2.6
Amber Janosh
*/
import java.util.Scanner;
public class ProgSix
{
    public static void main(String[]args)
    {
        Scanner input = new Scanner(System.in);

        int num = 0;
        int sum = 0;

        System.out.print("Enter a number from 0 to 1000: ");
        num = input.nextInt();

        while(num > 0)
        {
            sum = sum + num % 10;
            num = num / 10;
        }
        System.out.println("Sum of the digits is: " + sum);
    }
}
