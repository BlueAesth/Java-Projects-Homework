/* CS 249 Assignment Two
Chapter Two, 2.1-2.6

Program 2.3
Amber Janosh
*/
import java.util.Scanner;
public class ProgThree
{
    public static void main(String[]args)
    {
        System.out.println("Enter a value for feet: ");
        Scanner input = new Scanner(System.in);
        double feet = input.nextDouble();

        double meter = 0;
        meter = feet * 0.3048;

        System.out.println(feet + " feet is " + meter + " meters.");
    }
}