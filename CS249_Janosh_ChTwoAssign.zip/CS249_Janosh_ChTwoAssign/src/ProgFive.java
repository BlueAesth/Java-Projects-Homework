/* CS 249 Assignment Two
Chapter Two, 2.1-2.6

Program 2.5
Amber Janosh
*/
import java.util.Scanner;
public class ProgFive
{
    public static void main(String[]args)
    {
        Scanner input = new Scanner(System.in);

        System.out.println("Enter Subtotal: ");
        double sTotal = input.nextDouble();
        System.out.println("\n");

        System.out.println("Enter tip percentage: ");
        double tipPerc = input.nextDouble();
        System.out.println("\n");

        double tipDec = tipPerc/100;
        double tip = tipDec * sTotal;
        double total = sTotal + tip;

        System.out.println("Subtotal: $" + sTotal + "\n");
        System.out.println("Tip: $" + tip + "\n\n");
        System.out.println("Total: $" + total + "\n");
    }
}