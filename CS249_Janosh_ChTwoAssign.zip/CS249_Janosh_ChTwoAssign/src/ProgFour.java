/* CS 249 Assignment Two
Chapter Two, 2.1-2.6

Program 2.4
Amber Janosh
*/
import java.util.Scanner;
public class ProgFour
{
    public static void main(String[]args)
    {
        System.out.println("Enter a number in pounds: ");
        Scanner input = new Scanner(System.in);
        double pounds = input.nextDouble();

        double kilo = 0;
        kilo = pounds * 0.453592;

        System.out.println(pounds + " pounds is " + kilo + " kilograms.");
    }
}