/* CS 249 Assignment Two
Chapter Two, 2.1-2.6

Program 2.1
Amber Janosh
*/
import java.util.Scanner;
public class ProgOne
{
    public static void main(String[]args)
    {
        double fahr;
        double cels;

        Scanner input = new Scanner(System.in);

        System.out.println("Enter a degree in Celsius: ");

        cels = input.nextDouble();
        System.out.println("\n");

        fahr = (cels * 1.8) + 32;

        System.out.println(cels + " Celsius is " + fahr + " Fahrenheit.");
    }
}