/* CS 249 Assignment Two
Chapter Two, 2.1-2.6

Program 2.2
Amber Janosh
*/
import java.util.Scanner;
public class ProgTwo
{
    public static void main(String[]args)
    {
        double radi;
        double leng;
        double area;
        double volu;

        Scanner input = new Scanner(System.in);

        System.out.println("Enter the radius and length of a cylinder: ");

        radi = input.nextDouble();
        leng = input.nextDouble();

        area = radi * radi * 3.14159265359;
        volu = area * leng;

        System.out.println("The area is " + area);
        System.out.println("The volume is " + volu);
    }
}