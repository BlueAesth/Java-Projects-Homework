import java.util.Arrays;
import java.util.Scanner;
/*
(Business: check ISBN-13) ISBN-13 is a new standard for identifying books. It
uses 13 digits d1d2d3d4d5d6d7d8d9d10d11d12d13. The last digit d13 is a checksum,
which is calculated from the other digits using the following formula:
10 - (d1 + 3d2 + d3 + 3d4 + d5 + 3d6 + d7 + 3d8 + d9 + 3d10 + d11 + 3d12),10
If the checksum is 10, replace it with 0. Your program should read the input as a
string. Display “invalid input” if the input is invalid.
 */

public class Ch5Prog47 {
        public static void main(String[]args) {
            Scanner input = new Scanner(System.in);

            char[] userNumsArr = new char[12];
            int[] userNumsArrint = new int[12];

            String num;
            int chkSum = 0;

            System.out.println("Please enter twelve digits to be converted to ISBN-13.");
            num = input.nextLine();

            if (num.length() < 12) {
                System.out.println("Not enough numbers!");
            }
            else if(num.length() > 12) {
                System.out.println("Too many numbers!");
            }
            else if(num.matches(".*[a-z].*")) {
                System.out.println("Letters are not allowed!");
            }
            else {
                userNumsArr = num.toCharArray();

                for (int i = 0; i < userNumsArr.length; i++) {
                    userNumsArrint[i] = Character.getNumericValue(userNumsArr[i]);
                }

                chkSum = (10 - (userNumsArrint[0] + (3 * userNumsArrint[1]) + userNumsArrint[2] + (3 * userNumsArrint[3]) + userNumsArrint[4] + (3 * userNumsArrint[5]) + userNumsArrint[6] + (3 * userNumsArrint[7]) + userNumsArrint[8] + (3 * userNumsArrint[9]) + userNumsArrint[10] + (3 * userNumsArrint[11])) % 10);

                if (chkSum == 10) {
                    chkSum = 0;
                }

                System.out.println("Your ISBN-13 is: " + Arrays.toString(userNumsArrint).replace("[", "").replace("]","").replace(",","").replace(" ", "") + chkSum);
            }


        }
}
