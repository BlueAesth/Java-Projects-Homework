import java.util.Random;
import java.util.Scanner;
    /**
     * Amber Janosh
     * CS249
     * Assignment Five, Program 34
     *(Game: scissor, rock, paper) Programming Exercise 3.17 gives a program that
     * plays the scissor–rock–paper game. Revise the program to let the user continuously play
     * until either the user or the computer wins more than two times than its opponent.
     **/
    public class Ch5Prog34 {
        public static void main(String[] args) {

            Scanner input = new Scanner(System.in);
            Random ran = new Random();

            int compNum = 0;
            int userNum = 0;
            int userScore = 0;
            int compScore = 0;
            int flag = 0;

            while(flag != -1) {
                compNum = ran.nextInt(4);

                System.out.println("Pick Scissors? Enter 0");
                System.out.println("Pick Rock? Enter 1");
                System.out.println("Pick Paper? Enter 2");

                userNum = input.nextInt();

                if (compNum == 0)
                    System.out.println("Computer got Scissors, ");
                else if (compNum == 1)
                    System.out.println("Computer got Rock, ");
                else
                    System.out.println("Computer got Paper, ");

                if (userNum == 0)
                    System.out.println("User got Scissors, ");
                else if (userNum == 1)
                    System.out.println("User got Rock, ");
                else
                    System.out.println("User got Paper, ");


                if (userNum == compNum) {
                    System.out.println("It is a draw!");
                    userScore++;
                    compScore++;
                    System.out.println("UserScore: " + userScore);
                    System.out.println("compScore: " + compScore);
                } else if (compNum == 0) { //Scissors
                    if (userNum == 1) { //Rock
                        System.out.println("User Won!");
                        userScore++;
                        System.out.println("UserScore: " + userScore);
                        System.out.println("compScore: " + compScore);
                    } else {
                        System.out.println("Computer won!");
                        compScore++;
                        System.out.println("UserScore: " + userScore);
                        System.out.println("compScore: " + compScore);
                    }
                } else if (compNum == 1) { //Rock
                    if (userNum == 0) { //Scissors
                        System.out.println("Computer Won!");
                        compScore++;
                        System.out.println("UserScore: " + userScore);
                        System.out.println("compScore: " + compScore);
                    } else {
                        System.out.println("User won!");
                        userScore++;
                        System.out.println("UserScore: " + userScore);
                        System.out.println("compScore: " + compScore);
                    }
                } else if (compNum == 2) { //Paper
                    if (userNum == 1) { //Scissors
                        System.out.println("User Won!");
                        userScore++;
                        System.out.println("UserScore: " + userScore);
                        System.out.println("compScore: " + compScore);
                    } else {
                        System.out.println("Computer won!");
                        compScore++;
                        System.out.println("UserScore: " + userScore);
                        System.out.println("compScore: " + compScore);
                    }

                }


                if ((userScore!=0)&&(compScore!=0)) {
                    if (userScore > (2*compScore)){
                        System.out.println("\nEnd Game");
                        flag = -1;
                        System.out.println("User totally won!");
                        System.out.println("UserScore: " + userScore);
                        System.out.println("compScore: " + compScore);
                    } else if (compScore > (2*userScore)) {
                        System.out.println("Computer totally Won!");
                        System.out.println("compScore: " + compScore);
                        System.out.println("UserScore: " + userScore);
                        flag = -1;
                    }
                }
            }
        }
    }

