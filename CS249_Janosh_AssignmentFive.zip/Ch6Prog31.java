import java.util.Arrays;
import java.util.Scanner;
/*
Write a program that prompts the user to enter a credit card number as a long
integer. Display whether the number is valid or invalid.

Java Book Page: 268
Ch6 Program 31
*/
public class Ch6Prog31 {
/*--------Validation Method------------*/
    public static boolean isValid (long[] arr2){
        int sum = 0;
        int calcLen = arr2.length;
        for (int i = 0; i < calcLen; i++) {
            long dig = arr2[calcLen - i - 1];

            if (i % 2 == 1) {
                dig *= 2;
            }
            sum += dig > 9 ? dig - 9 : dig;
        }
        return sum % 10 == 0;
    }

/*--------MAIN METHOD-------------------------*/
    public static void main(String[] args){
        Scanner input = new Scanner(System.in);

        System.out.println("Please enter your credit card number: ");
        System.out.println("No leading zeros!");
        long ccNum;
        ccNum = input.nextLong();

/*-------------long to string to char arr to long arr---------*/
        String str = (new Long(ccNum)).toString();
        char[] chArr = str.toCharArray();
        long[] arr = new long[chArr.length];

        for (int i = 0; i< chArr.length; i++) {
            arr[i] = Character.getNumericValue(chArr[i]);
        }

/*-----------Card Length Validation-----------------*/
        int numLen = arr.length;

        if(numLen < 13){
            System.out.println("The credit card number is too short.");
            System.out.println("REJECTED CARD");
            System.exit(0);
        }
        else if(numLen > 16){
            System.out.println("The credit card is too long.");
            System.out.println("REJECTED CARD");
            System.exit(0);
        }
        else {
            //System.out.println(Arrays.toString(arr));

/*-----------------Prefix------------------------------------*/
        String preFix = "Default";

        if ((arr[0] == 3) && (arr[1] == 7)) {
            preFix = "American Express";
        } else if (arr[0] == 4) {
            preFix = "Visa";
        } else if (arr[0] == 5) {
            preFix = "Master";
        } else if (arr[0] == 6) {
            preFix = "Discover";
        } else {
            System.out.println("REJECTED CARD");
            System.exit(0);
        }

/*-------validation method call and printing--------------*/
        boolean result = isValid(arr);

        if(result == false){
            System.out.println("Card was rejected");
        }
        else if(result == true){
            System.out.println(preFix + " Card was accepted!");
        }
        }
    }
}