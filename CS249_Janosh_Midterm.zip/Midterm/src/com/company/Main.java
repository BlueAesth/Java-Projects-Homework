/*
Amber Janosh
CS249 Midterm

This program functions as a To-Do list.

Requirements:
Proper Commenting
OOP Style
Multiple classes
Working program
Loops
Rudimentary command line interface

Create object "todo Listing"
    Title
    Description
    Date created
    Completed/Not Competed
        Date completed
Create array list of todolisting objects
Create menu
    Complete task
    Delete task
    Add task
    List Todo List
        have a key for indexing tasks
*/

package com.company;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner input = new Scanner(System.in); //Creates input

        String choice; //Choice to continue making menu selections
        int contin = 3; //Int for String choice

        Menu menu = new Menu(); //Creating the menu object
        menu.setMenu(); //Setting up the menu options

        do { //Loop for menu selection
            menu.displayMenu();
            menu.setSelection(); //Asks the user which menu selection they want

            System.out.println("\nWould you like to make another choice? Please type yes or no.");
            choice = input.nextLine();
            choice = choice.toLowerCase();

            if (choice.equals("yes")){
                contin = 1;
            }
            else if (choice.equals("no")){
                contin = 0;
            }

        } while (contin == 1);

        System.out.println("Thank you! Good-bye.");
    }
}
