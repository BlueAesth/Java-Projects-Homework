/* CS249 Chapter Four Assignment
Program 4.15
Amber Janosh

4.15 (Phone key pads) The international standard letter/number mapping found on the
telephone is shown below:
Write a program that prompts the user to enter a lowercase or uppercase letter and displays its corresponding number. For a nonletter input, display invalid
input.
Enter a letter: A
The corresponding number is 2
Enter a letter: a
The corresponding number is 2
Enter a letter: +
+ is an invalid input

 */
import java.util.Scanner;
public class ProgFifteen {
    public static void main(String[]args) {

        Scanner input = new Scanner(System.in);

        String str = new String("");

        System.out.println("Please enter a character from a phone keypad: ");
        System.out.println("Note: Use % for Voice Mail, * for Star and # for Pound.");

        str = input.next();
        str = str.toLowerCase();

        if((str.equals("a"))||(str.equals("b"))||(str.equals("c"))){
            System.out.println("The number is 2.");
        }
        else if ((str.equals("d"))||(str.equals("e"))||(str.equals("f"))){
            System.out.println("The number is 3.");
        }
        else if ((str.equals("g"))||(str.equals("h"))||(str.equals("i"))){
            System.out.println("The number is 4.");
        }
        else if ((str.equals("j"))||(str.equals("k"))||(str.equals("l"))){
            System.out.println("The number is 5.");
        }
        else if ((str.equals("m"))||(str.equals("n"))||(str.equals("o"))){
            System.out.println("The number is 6.");
        }
        else if ((str.equals("p"))||(str.equals("q"))||(str.equals("r"))||(str.equals("s"))){
            System.out.println("The number is 7.");
        }
        else if ((str.equals("t"))||(str.equals("u"))||(str.equals("v"))){
            System.out.println("The number is 8.");
        }
        else if ((str.equals("w"))||(str.equals("x"))||(str.equals("y"))||(str.equals("z"))){
            System.out.println("The number is 9.");
        }
        else if ((str.equals("%"))){
            System.out.println("The number is 1.");
        }
        else if ((str.equals("0"))){
            System.out.println("The number is 0.");
        }
        else if ((str.equals("*"))){
            System.out.println("This is Star.");
        }
        else if ((str.equals("#"))){
            System.out.println("This is Pound.");
        }
        else {
            System.out.println("That's not on a phone!");
        }
    }
}
