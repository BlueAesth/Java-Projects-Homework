import java.util.Arrays;
import java.util.Scanner;

/* CS249 Assignment 6
Amber Janosh
Chapter 7 Program 26

(Strictly identical arrays) The arrays list1 and list2 are strictly identical
if their corresponding elements are equal. Write a method that returns true if
list1 and list2 are strictly identical, using the following header:
public static boolean equals(int[] list1, int[] list2)
Write a test program that prompts the user to enter two lists of integers and displays
whether the two are strictly identical. Here are the sample runs. Note the first number
in the input for each list indicates the number of the elements in the list.
This number is not part of the list.
*/
public class Ch7Prog26{

    public static boolean equals(int[] list1, int[] list2){
        int cnt = 1;
        for(int i = 0; i < list1.length; i++){
            if(list1[i] == list2[i]){
                cnt = 0;
            }
            else{
                cnt = 1;
            }
        }
        if(cnt > 0){
            return false;
        }
        else{
            return true;
        }
    }
/*--------MAIN--------*/
    public static void main(String[] args){
    Scanner input = new Scanner(System.in);

    int arrSize = 0;

    System.out.println("Please enter the amount of numbers you would like to use for each list: ");
    arrSize = input.nextInt();

    int[] arrOne = new int[arrSize];
    int[] arrTwo = new int[arrSize];

    System.out.println("Now enter the numbers for list one.");
    int num = 0;

    for(int i = 0; i < arrSize; i++){
        System.out.println("Number " + (i+1) + " :");
        num = input.nextInt();
        arrOne[i] = num;
    }

    System.out.println("Here is list one: " + Arrays.toString(arrOne));

    System.out.println("Now enter the numbers for list two.");
    num = 0;

    for(int i = 0; i < arrSize; i++){
        System.out.println("Number " + (i+1) + " :");
        num = input.nextInt();
        arrTwo[i] = num;
    }

    System.out.println("Here is list two: " + Arrays.toString(arrTwo));

    System.out.println("Now computing if lists match...");
    if(equals(arrOne, arrTwo)){
        System.out.println("The lists match!");
    }
    else{
        System.out.println("The lists do not match!");
    }
    }
}
