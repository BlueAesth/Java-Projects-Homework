import java.util.Random;

public class ProgTwntyFour {
    public static void main(String[] args) {
/*
Amber Janosh
CS249
Ch 3 program 24
(Game: pick a card) Write a program that simulates picking a card from a deck
of 52 cards. Your program should display the rank (Ace, 2, 3, 4, 5, 6, 7, 8, 9, 10,
Jack, Queen, King) and suit (Clubs, Diamonds, Hearts, Spades) of the card.
Here is a sample run of the program:
The card you picked is Jack of Hearts
 */
    Random ran = new Random();

    int cardNum = ran.nextInt(13);
    int cardSuit = ran.nextInt(4);

    String cardNumStr;
    String cardSuitStr;

    if (cardNum == 0){
        cardNumStr = "Ace";
    }
    else if (cardNum == 10){
        cardNumStr = "Jack";
    }
    else if (cardNum == 11){
        cardNumStr = "Queen";
    }
    else if (cardNum == 12){
        cardNumStr = "King";
    }
    else
        cardNumStr = String.valueOf(cardNum);

    switch(cardSuit+1){
        case 1: cardSuitStr = "Clubs";
        break;
        case 2: cardSuitStr = "Diamonds";
        break;
        case 3: cardSuitStr = "Hearts";
        break;
        case 4: cardSuitStr = "Spades";
        break;
        default: cardSuitStr = "Invalid Suit";
        break;
    }

    System.out.println("The card picked is: " + cardNumStr + " of " + cardSuitStr);
    }
}
