import java.util.Scanner;

public class ProgTwntyOne {
    public static void main(String[] args) {
/*
Amber Janosh
CS249
Ch 3 Problem 21

(Science: day of the week) Zeller’s congruence is an algorithm developed by
Christian Zeller to calculate the day of the week.
■ h is the day of the week (0: Saturday, 1: Sunday, 2: Monday, 3: Tuesday, 4:
Wednesday, 5: Thursday, and 6: Friday).
■ q is the day of the month.
■ m is the month (3: March, 4: April, ..., 12: December). January and February
are counted as months 13 and 14 of the previous year.
■ j is year\100
■ k is the year of the century (i.e., year % 100).
Note all divisions in this exercise perform an integer division. Write a program
that prompts the user to enter a year, month, and day of the month, and displays
the name of the day of the week. Here are some sample runs:
Enter year: (e.g., 2012): 2015
Enter month: 1−12: 1
Enter the day of the month: 1−31: 25
Day of the week is Sunday
Enter year: (e.g., 2012): 2012
Enter month: 1−12: 5
Enter the day of the month: 1−31: 12
Day of the week is Saturday
(Hint: January and February are counted as 13 and 14 in the formula, so you need
to convert the user input 1 to 13 and 2 to 14 for the month and change the year to
the previous year. For example, if the user enters 1 for m and 2015 for year, m will
be 13 and year will be 2014 used in the formula.)*/

        Scanner input = new Scanner(System.in);

        int h = 0; //Day; Sat 0 thru fri 6
        int q = 0; //Day number
        int m = 0; //Month
        int k = 0; //Year; ending year numbers '21 (2021/100)
        int j = 0; //Century 20  (2021 mod 100)

        int userYear = 0;
        int userMonth = 0;
        int userDay = 0;

        System.out.println("Enter the Year: ");
        userYear = input.nextInt();
        System.out.println("Enter the Month: ");
        userMonth = input.nextInt();
        System.out.println("Enter the Day: ");
        userDay = input.nextInt();
        System.out.println("\n");

        String monthString;
        switch (userMonth) {
            case 1:  monthString = "January";
                    userMonth = 13;
                    userYear--;
                break;
            case 2:  monthString = "February";
                    userMonth = 14;
                    userYear--;
                break;
            case 3:  monthString = "March";
                break;
            case 4:  monthString = "April";
                break;
            case 5:  monthString = "May";
                break;
            case 6:  monthString = "June";
                break;
            case 7:  monthString = "July";
                break;
            case 8:  monthString = "August";
                break;
            case 9:  monthString = "September";
                break;
            case 10: monthString = "October";
                break;
            case 11: monthString = "November";
                break;
            case 12: monthString = "December";
                break;
            default: monthString = "Invalid month";
                break;
        }

        q = userDay;
        m = userMonth;
        k = (userYear%100);
        j = (userYear/100);

        h = ((q + ((13*(m + 1))/5) + k + (k/4) + (j/4) + (5*j)) % 7); //Zeller Formula

        String dayString;
        switch (h+1) {
            case 1:  dayString = "Saturday";
                break;
            case 2:  dayString = "Sunday";
                break;
            case 3:  dayString = "Monday";
                break;
            case 4:  dayString = "Tuesday";
                break;
            case 5:  dayString = "Wednesday";
                break;
            case 6:  dayString = "Thursday";
                break;
            case 7:  dayString = "Friday";
                break;
            default: dayString = "Invalid month";
                break;
        }

        System.out.println("The day of the week is " + dayString + " for " + monthString + " " + q + ", " + (userYear + 1));
    }
}
