import java.util.Random;
import java.util.Scanner;

/**
 * Amber Janosh
 * CS249
 * Assignment Three
 *
 3.17 (Game: scissor, rock, paper) Write a program that plays the popular scissor–
 rock–paper game. (A scissor can cut a paper, a rock can knock a scissor, and
 a paper can wrap a rock.) The program randomly generates a number 0, 1, or
 2 representing scissor, rock, and paper. The program prompts the user to enter
 a number 0, 1, or 2 and displays a message indicating whether the user or the
 computer wins, loses, or draws. Here are sample runs:
 scissor (0), rock (1),Scanner in = new Scanner(System.in); paper (2): 1
 The computer is scissor. You are rock. You won
 scissor (0), rock (1), paper (2): 2
 The computer is paper. You are paper too. It is a draw
 **/

public class ProgSvnTn {
    public static void main(String[] args) {

    Scanner input = new Scanner(System.in);
    Random ran = new Random();

    int compNum = ran.nextInt(4);
    int userNum;



    System.out.println("Pick Scissors? Enter 0");
    System.out.println("Pick Rock? Enter 1");
    System.out.println("Pick Paper? Enter 2");

    userNum = input.nextInt();

    if (compNum == 0)
        System.out.println("Computer got Scissors, ");
        else if (compNum == 1)
            System.out.println("Computer got Rock, ");
            else
                System.out.println("Computer got Paper, ");

    if (userNum == 0)
        System.out.println("User got Scissors, ");
        else if (userNum == 1)
            System.out.println("User got Rock, ");
            else
                System.out.println("User got Paper, ");


    if (userNum==compNum) {
        System.out.println("It is a draw!");
    }
        else if (compNum == 0){ //Scissors
            if (userNum == 1){ //Rock
                System.out.println("User Won!");
            }
            else {
                System.out.println("Computer won!");
            }
        }

        else if (compNum == 1){ //Rock
            if (userNum == 0){ //Scissors
                System.out.println("Computer Won!");
            }
            else {
                System.out.println("User won!");
            }
        }

        else if (compNum == 2){ //Paper
            if (userNum == 1){ //Scissors
                System.out.println("User Won!");
            }
            else {
                System.out.println("Computer won!");
            }
        }
    }
}