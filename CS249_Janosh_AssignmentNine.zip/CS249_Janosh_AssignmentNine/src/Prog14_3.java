/*
Amber Janosh
CS249
Assignment Nine
Program 14.3

(Display three cards) Write a program that displays three cards randomly
selected from a deck of 52, as shown in Figure 14.43c. The card image files are
named 1.png, 2.png, . . . , 52.png and stored in the image/card directory. All
three cards are distinct and selected randomly. (Hint: You can select random
cards by storing the numbers 1–52 to an array list, perform a random shuffle
introduced in Section 11.12, and use the first three numbers in the array list as
the file names for the image.)
 */
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.geometry.Insets;
import java.util.Random;

public class Prog14_3 extends Application {
    @Override
    public void start(Stage primaryStage){
        Pane pane = new HBox(10);
        pane.setPadding(new Insets(5,5,5,5));

        Random rand = new Random();
        int randBound = 53;

        String[] cards = new String[52];
        String cardPOS;

        for (int i = 0; i < cards.length; i++){
            cardPOS = String.valueOf(i+1);
            cards[i] = cardPOS;
        }

        for(int i = 0; i < 3; i++) {
            int cardNum = rand.nextInt(randBound);
            String imagePath = "image/card/" + cards[cardNum] + ".png";

            Image image = new Image(imagePath);
            ImageView imageview = new ImageView(image);
            pane.getChildren().add(imageview);
        }

        Scene scene = new Scene(pane);
        primaryStage.setTitle("Three Cards @ Random");
        primaryStage.setScene(scene);
        primaryStage.show();
    }
}
