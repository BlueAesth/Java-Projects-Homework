/*
Amber Janosh
CS249
Assignment Nine
Program 14.1

-I used my own images

Write a program that displays four images in a grid pane.
*/

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
import org.jetbrains.annotations.NotNull;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

public class Prog14_1 extends Application{
    @Override
    public void start(@NotNull Stage primaryStage) {
        GridPane pane = new GridPane();
        pane.setAlignment(Pos.CENTER);
        pane.setPadding(new Insets(11.5, 12.5, 13.5, 14.5));
        pane.setHgap(5.5);
        pane.setVgap(5.5);

        Image cat = new Image("image/BlackCat.jpg");
        Image crest = new Image("image/HylianCrest.jpg");
        Image beach = new Image("image/NSB.jpg");
        Image music = new Image("image/Wavelength.jpg");

        ImageView imageView = new ImageView(cat);
        ImageView imageView2 = new ImageView(crest);
        ImageView imageView3 = new ImageView(beach);
        ImageView imageView4 = new ImageView(music);

        pane.add(imageView, 0, 0);
        pane.add(imageView2,0,1);
        pane.add(imageView3,1,0);
        pane.add(imageView4,1,1);

        Scene scene = new Scene(pane);
        primaryStage.setTitle("Images on a Grid Pane");
        primaryStage.setScene(scene);
        primaryStage.show();
    }
}
