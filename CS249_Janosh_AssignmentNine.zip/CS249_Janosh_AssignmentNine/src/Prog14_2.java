/*
Amber Janosh
CS249
Assignment Nine
Program 14.2

-I didn't realize before making this that there was x's and o's in the
image folder you sent, so I used custom ones.

(Tic-tac-toe board) Write a program that displays a tic-tac-toe board, as
shown in Figure 14.43b. A cell may be X, O, or empty. What to display
at each cell is randomly decided. The X and O are the image files x.gif
and o.gif.
 */

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
import org.jetbrains.annotations.NotNull;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

public class Prog14_2 extends Application{
    @Override
    public void start(@NotNull Stage primaryStage) {
        GridPane gridPane = new GridPane();

        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                int rand = (int)(Math.random() * 3);
                if (rand == 0)
                    gridPane.add(new ImageView(new Image("image/O.jpg")), j, i);
                else if (rand == 1)
                    gridPane.add(new ImageView(new Image("image/X.jpg")), j, i);
                else
                    continue;
            }
        }

        Scene scene = new Scene(gridPane);
        primaryStage.setTitle("Random Tic Tac Toe!~");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args){
        Application.launch(args);
    }
}
