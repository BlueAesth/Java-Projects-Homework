/*
Amber Janosh
CS249
Assignment Nine
Chapter 14 Program 7

(Display random 0 or 1) Write a program that displays a 10-by-10 square matrix,
as shown in Figure 14.45a. Each element in the matrix is 0 or 1, randomly generated.
Display each number centered in a text field. Use TextField’s setText
method to set value 0 or 1 as a string.
 */

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.scene.layout.GridPane;
import javafx.scene.control.TextField;
import javafx.geometry.HPos;
import javafx.geometry.VPos;
import javafx.geometry.Insets;

public class Prog14_7 extends Application {
        @Override
        public void start(Stage primaryStage) {
            GridPane pane = new GridPane();
            pane.setPadding(new Insets(5, 5, 5, 5));
            pane.setHgap(10);
            pane.setVgap(10);

            for (int i = 0; i < 10; i++) {
                for (int j = 0; j < 10; j++) {
                    TextField textf = new TextField();
                    textf.setPrefColumnCount(1);
                    textf.setText(String.valueOf((int)(Math.random() * 2)));
                    pane.add(textf, i, j);
                    pane.setHalignment(textf, HPos.CENTER);
                    pane.setValignment(textf, VPos.CENTER);
                }
            }

            Scene scene = new Scene(pane);
            primaryStage.setTitle("Binary Matrix!~");
            primaryStage.setScene(scene);
            primaryStage.show();
        }
    }