/* CS 249 Assignment One
Chapter One, 1.1-1.6

Program 1.3
Amber Janosh
*/
public class ProgThree
{
    public static void main(String[] args)
    {
        System.out.println("   J    a   v     v  a ");
        System.out.println("   J   a a   v   v  a a");
        System.out.println("J  J  aaaaa   V V  aaaaa");
        System.out.println(" JJ  a     a   V  a     a");
    }
}
