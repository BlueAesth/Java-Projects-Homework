/* CS 249 Assignment One
Chapter One, 1.1-1.6

Program 1.2
Amber Janosh
*/
public class ProgTwo
{
    public static void main(String[] args)
    {
        System.out.println("Welcome to Java");
        System.out.println("Welcome to Java");
        System.out.println("Welcome to Java");
        System.out.println("Welcome to Java");
        System.out.println("Welcome to Java");
    }
}
