/* CS 249 Assignment One
Chapter One, 1.1-1.6

Program 1.6
Amber Janosh
*/
public class ProgSix
{
        public static void main(String[] args)
        {
            //System.out.print("1 + 2 + 3 + 4 + 5 + 6 + 7 + 8 + 9 = ");
            System.out.println(1 + 2 + 3 + 4 + 5 + 6 + 7 + 8 + 9);    //45
        }
}
