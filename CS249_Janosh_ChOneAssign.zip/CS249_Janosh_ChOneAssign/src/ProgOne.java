/* CS 249 Assignment One
Chapter One, 1.1-1.6

Program 1.1
Amber Janosh
*/
class ProgOne
{
    public static void main(String[] args)
    {
        System.out.println("Welcome to Java");
        System.out.println("Welcome to Computer Science");
        System.out.println("Programming is fun");
    }
}